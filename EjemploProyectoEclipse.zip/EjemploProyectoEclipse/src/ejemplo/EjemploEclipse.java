package ejemplo;

import java.util.Scanner;

public class EjemploEclipse {
	
	 public static void main(String[] args) {
		 
		 Scanner teclado = new Scanner(System.in);
		 
		 String finalizar;
		 
		 System.out.println("Ejemplo de proyecto en Eclipse");
		 
		 System.out.println("Deber�s importarlo en IntelliJ IDEA");
		 
		 System.out.println("Presiona una tecla para continuar");
		 
		 finalizar=teclado.nextLine();
		 
	 }

}
