/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemploproyectonb;

import java.util.Scanner;

/**
 *
 * @author Usuario1
 */
public class EjemploProyectoNB {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Scanner sc = new Scanner(System.in);

        System.out.println("dime un número");
        float numero = sc.nextFloat();
        if (numero < 0) {
            System.out.println("error");
        } else {
            System.out.println("la raíz cuadrada del número es: " + Math.sqrt(numero));

        }

    }

}
